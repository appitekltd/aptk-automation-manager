/*
 *  @module $Force
 *  @desc Used to interact with the ForceTek library for both sandbox and
 *    production environments
 */
var $Force = {
  'Salesforce': {}
};